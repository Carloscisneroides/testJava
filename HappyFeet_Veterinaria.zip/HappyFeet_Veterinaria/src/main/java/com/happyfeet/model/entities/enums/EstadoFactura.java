package com.happyfeet.model.entities.enums;

public enum EstadoFactura {
    PENDIENTE,
    PAGADA,
    ANULADA
}