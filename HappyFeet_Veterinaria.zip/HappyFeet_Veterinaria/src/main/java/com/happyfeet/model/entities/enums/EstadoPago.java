package com.happyfeet.model.entities.enums;

public enum EstadoPago {
    PENDIENTE,
    COMPLETADO,
    FALLIDO,
    ANULADO
}
