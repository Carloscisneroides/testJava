package com.happyfeet.model.entities.enums;

public enum NivelPuntos {
    BRONCE,
    PLATA,
    ORO,
    DIAMANTE
}