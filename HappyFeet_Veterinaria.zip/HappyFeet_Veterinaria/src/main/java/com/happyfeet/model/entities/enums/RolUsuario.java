package com.happyfeet.model.entities.enums;

public enum RolUsuario {
    ADMIN,
    VETERINARIO,
    RECEPCIONISTA,
    CLIENTE
}