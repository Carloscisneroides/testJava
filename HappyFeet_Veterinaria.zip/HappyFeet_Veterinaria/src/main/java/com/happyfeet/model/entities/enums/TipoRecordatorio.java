package com.happyfeet.model.entities.enums;

public enum TipoRecordatorio {
    VACUNACION,
    DESPARASITACION,
    CITA,
    OTRO
}
