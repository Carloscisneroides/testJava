package com.happyfeet.service.billing;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Decorador que aplica descuentos.
 * SOLID: SRP - solo aplica descuentos.
 */
public class DiscountDecorator extends FacturaDecorator {

    private final BigDecimal discountPercentage;
    private final String discountReason;

    public DiscountDecorator(FacturaComponent component, BigDecimal discountPercentage, String discountReason) {
        super(component);
        this.discountPercentage = discountPercentage;
        this.discountReason = discountReason;
    }

    @Override
    public BigDecimal calculateTotal() {
        BigDecimal baseTotal = super.calculateTotal();
        BigDecimal discount = baseTotal.multiply(discountPercentage).setScale(2, RoundingMode.HALF_UP);
        return baseTotal.subtract(discount);
    }

    @Override
    public String generateDescription() {
        BigDecimal baseTotal = wrappedComponent.calculateTotal();
        BigDecimal discount = baseTotal.multiply(discountPercentage).setScale(2, RoundingMode.HALF_UP);

        return super.generateDescription() +
               String.format("\n  - Descuento %s (%.0f%%): -$%.2f",
                   discountReason,
                   discountPercentage.multiply(new BigDecimal("100")),
                   discount);
    }
}