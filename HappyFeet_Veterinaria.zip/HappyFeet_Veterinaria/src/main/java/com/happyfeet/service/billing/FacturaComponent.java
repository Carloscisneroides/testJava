/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.happyfeet.service.billing;

/**
 *
 * @author camper
 */

import com.happyfeet.model.entities.Factura;
import java.math.BigDecimal;

/**
 * Componente base para decoradores de factura.
 * SOLID: Liskov Substitution - todos los decoradores son sustituibles.
 */
public interface FacturaComponent {
    BigDecimal calculateTotal();
    String generateDescription();
    Factura getFactura();
}