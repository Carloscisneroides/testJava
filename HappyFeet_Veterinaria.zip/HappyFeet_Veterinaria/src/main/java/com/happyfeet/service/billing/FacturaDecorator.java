package com.happyfeet.service.billing;

import com.happyfeet.model.entities.Factura;
import java.math.BigDecimal;

/**
 * Decorador base abstracto.
 * SOLID: Open/Closed - se extiende sin modificar.
 */
public abstract class FacturaDecorator implements FacturaComponent {

    protected final FacturaComponent wrappedComponent;

    public FacturaDecorator(FacturaComponent wrappedComponent) {
        this.wrappedComponent = wrappedComponent;
    }

    @Override
    public BigDecimal calculateTotal() {
        return wrappedComponent.calculateTotal();
    }

    @Override
    public String generateDescription() {
        return wrappedComponent.generateDescription();
    }

    @Override
    public Factura getFactura() {
        return wrappedComponent.getFactura();
    }
}