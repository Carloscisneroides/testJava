package com.happyfeet.service.billing;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Decorador para cargos de servicio.
 * SOLID: Open/Closed - se pueden añadir más tipos de cargos.
 */
public class ServiceChargeDecorator extends FacturaDecorator {

    private final BigDecimal chargeAmount;
    private final String chargeName;

    public ServiceChargeDecorator(FacturaComponent component, BigDecimal chargeAmount, String chargeName) {
        super(component);
        this.chargeAmount = chargeAmount;
        this.chargeName = chargeName;
    }

    @Override
    public BigDecimal calculateTotal() {
        return super.calculateTotal().add(chargeAmount);
    }

    @Override
    public String generateDescription() {
        return super.generateDescription() +
               String.format("\n  + %s: $%.2f", chargeName, chargeAmount);
    }

    // Factory methods
    public static ServiceChargeDecorator withDeliveryFee(FacturaComponent component) {
        return new ServiceChargeDecorator(component, new BigDecimal("5000"), "Cargo por domicilio");
    }

    public static ServiceChargeDecorator withUrgencyFee(FacturaComponent component) {
        return new ServiceChargeDecorator(component, new BigDecimal("15000"), "Cargo por urgencia");
    }
}