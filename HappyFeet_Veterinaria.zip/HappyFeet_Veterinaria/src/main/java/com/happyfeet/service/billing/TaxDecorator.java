package com.happyfeet.service.billing;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Decorador que añade cálculo de impuestos adicionales.
 * SOLID: SRP - solo maneja impuestos.
 */
public class TaxDecorator extends FacturaDecorator {

    private final BigDecimal taxRate;
    private final String taxName;

    public TaxDecorator(FacturaComponent component, BigDecimal taxRate, String taxName) {
        super(component);
        this.taxRate = taxRate;
        this.taxName = taxName;
    }

    @Override
    public BigDecimal calculateTotal() {
        BigDecimal baseTotal = super.calculateTotal();
        BigDecimal tax = baseTotal.multiply(taxRate).setScale(2, RoundingMode.HALF_UP);
        return baseTotal.add(tax);
    }

    @Override
    public String generateDescription() {
        BigDecimal baseTotal = wrappedComponent.calculateTotal();
        BigDecimal tax = baseTotal.multiply(taxRate).setScale(2, RoundingMode.HALF_UP);

        return super.generateDescription() +
               String.format("\n  + %s (%.1f%%): $%.2f", taxName, taxRate.multiply(new BigDecimal("100")), tax);
    }

    // Factory methods
    public static TaxDecorator withIVA(FacturaComponent component) {
        return new TaxDecorator(component, new BigDecimal("0.19"), "IVA");
    }

    public static TaxDecorator withSalesTax(FacturaComponent component) {
        return new TaxDecorator(component, new BigDecimal("0.08"), "Impuesto de Ventas");
    }
}