package com.happyfeet.service.billing;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Decorador para aplicar cobertura de seguro.
 * SOLID: SRP - solo maneja lógica de seguro.
 */
public class ensuranceDecorator extends FacturaDecorator {

    private final BigDecimal coveragePercentage;
    private final String insuranceProvider;

    public ensuranceDecorator(FacturaComponent component, BigDecimal coveragePercentage, String insuranceProvider) {
        super(component);
        this.coveragePercentage = coveragePercentage;
        this.insuranceProvider = insuranceProvider;
    }

    @Override
    public BigDecimal calculateTotal() {
        BigDecimal baseTotal = super.calculateTotal();
        BigDecimal coverage = baseTotal.multiply(coveragePercentage).setScale(2, RoundingMode.HALF_UP);
        return baseTotal.subtract(coverage);
    }

    @Override
    public String generateDescription() {
        BigDecimal baseTotal = wrappedComponent.calculateTotal();
        BigDecimal coverage = baseTotal.multiply(coveragePercentage).setScale(2, RoundingMode.HALF_UP);

        return super.generateDescription() +
               String.format("\n  - Cobertura seguro %s (%.0f%%): -$%.2f",
                   insuranceProvider,
                   coveragePercentage.multiply(new BigDecimal("100")),
                   coverage);
    }
}