/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.happyfeet.service.reports;

/**
 *
 * @author camper
 */
public abstract class AbstractReportGenerator {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /**
     * Template Method - define el algoritmo completo.
     */
    public final String generateReport() {
        StringBuilder report = new StringBuilder();

        // Pasos fijos
        report.append(generateHeader());
        report.append("\n");

        // Paso personalizable
        report.append(generateBody());
        report.append("\n");

        // Pasos opcionales con hooks
        if (shouldIncludeSummary()) {
            report.append(generateSummary());
            report.append("\n");
        }

        if (shouldIncludeFooter()) {
            report.append(generateFooter());
        }

        // Post-procesamiento
        return postProcess(report.toString());
    }

    // Métodos abstractos - deben implementarse
    protected abstract String getReportTitle();
    protected abstract String generateBody();

    // Métodos con implementación por defecto - pueden sobreescribirse
    protected String generateHeader() {
        return String.format("""
            ╔════════════════════════════════════════════════════════════════╗
            ║  %s
            ║  Generado: %s
            ╚════════════════════════════════════════════════════════════════╝
            """,
            getReportTitle(),
            LocalDateTime.now().format(FORMATTER));
    }

    protected String generateFooter() {
        return String.format("""
            ────────────────────────────────────────────────────────────────
            HappyFeet Veterinaria - Sistema de Gestión Integral
            Reporte generado automáticamente
            """);
    }

    protected String generateSummary() {
        return ""; // Por defecto vacío
    }

    // Hook methods - controlan flujo
    protected boolean shouldIncludeSummary() {
        return true;
    }

    protected boolean shouldIncludeFooter() {
        return true;
    }

    // Post-procesamiento
    protected String postProcess(String report) {
        return report; // Por defecto sin cambios
    }
}