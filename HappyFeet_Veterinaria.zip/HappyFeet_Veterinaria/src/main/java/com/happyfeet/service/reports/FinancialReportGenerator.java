/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.happyfeet.service.reports;

/**
 *
 * @author camper
 */
 */
public class FinancialReportGenerator extends AbstractReportGenerator {

    private final FacturaRepository facturaRepository;
    private final YearMonth periodo;

    public FinancialReportGeneratorenerator(FacturaRepository facturaRepository, YearMonth periodo) {
        this.facturaRepository = facturaRepository;
        this.periodo = periodo;
    }

    @Override
    protected String getReportTitle() {
        return String.format("REPORTE FINANCIERO - %s/%d",
            periodo.getMonth().name(), periodo.getYear());
    }

    @Override
    protected String generateBody() {
        LocalDate inicio = periodo.atDay(1);
        LocalDate fin = periodo.atEndOfMonth();

        List<Factura> facturas = facturaRepository.findByFechaEmisionBetween(
            inicio.atStartOfDay(), fin.atTime(23, 59, 59));

        StringBuilder body = new StringBuilder();
        body.append(String.format("%-10s %-15s %-15s %-15s %-15s%n",
            "Factura", "Fecha", "Subtotal", "IVA", "Total"));
        body.append("─".repeat(70)).append("\n");

        for (Factura factura : facturas) {
            body.append(String.format("%-10d %-15s $%-14.2f $%-14.2f $%-14.2f%n",
                factura.getId(),
                factura.getFechaEmision().toLocalDate(),
                factura.getSubtotal(),
                factura.getIva(),
                factura.getTotal()
            ));
        }

        return body.toString();
    }

    @Override
    protected String generateSummary() {
        LocalDate inicio = periodo.atDay(1);
        LocalDate fin = periodo.atEndOfMonth();

        List<Factura> facturas = facturaRepository.findByFechaEmisionBetween(
            inicio.atStartOfDay(), fin.atTime(23, 59, 59));

        BigDecimal totalIngresos = facturas.stream()
            .map(Factura::getTotal)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalIva = facturas.stream()
            .map(Factura::getIva)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        return String.format("""
            ════════════════════════════════════════════════════════════════
            RESUMEN FINANCIERO:
              • Total de facturas: %d
              • Ingresos totales: $%.2f
              • IVA recaudado: $%.2f
              • Promedio por factura: $%.2f
            ════════════════════════════════════════════════════════════════
            """,
            facturas.size(),
            totalIngresos,
            totalIva,
            facturas.isEmpty() ? 0 : totalIngresos.divide(new BigDecimal(facturas.size()), 2, java.math.RoundingMode.HALF_UP)
        );
    }
}